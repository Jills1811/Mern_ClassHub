#include <bits/stdc++.h>
using namespace std;

int main() {
    vector<int> S = {5, 4, 6, 9};
    int m = 5, val1, val2;
    // I/P conversion
    vector<int> P = S;
    vector<int> W = S;
    int capacity = m, n = S.size();
    vector<vector<int>> T(n + 1, vector<int>(m + 1, 0));
    for(int i = 0; i <= n; i++)
    {
        for(int j = 0; j <= m; j++)
        {
            if(i == 0 || j == 0)
            {
                T[i][j] = 0;
            }
            else
            {
                if(j >= W[i - 1])
                {
                    val1 = T[i - 1][j];
                    val2 = P[i - 1] + T[i - 1][j - W[i - 1]];
                    T[i][j] = max(val1, val2);
                }
                else
                {
                    T[i][j] = T[i - 1][j];
                }
            }
        }
    }
    for(int i = 0; i <= n; i++)
    {
        for(int j = 0; j <= m; j++)
        {
            cout << T[i][j] << " ";            
        }
        cout << endl;
    }
    return 0;
}
