#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>
#include <stack>
#include <bits/stdc++.h>

using namespace std;

struct Point {
    int x;
    int y;
};

int n = 8;

int Direction(Point P, Point Q, Point R)
{
    Point PQ, PR;
    PR.x = R.x - P.x;
    PR.y = R.y - P.y;

    PQ.x = Q.x - P.x;
    PQ.y = Q.y - P.y;

    int d = (PQ.x * PR.y) - (PQ.y * PR.x);

    return d;
}

void calculate_angles(vector<pair<double, int>>* angles, int index, Point p[8])
{
    double angle;
    int up, down;

    for (int i = 0; i < n; i++) {
        if (i != index) {
            up = p[i].y - p[index].y;
            down = p[i].x - p[index].x;
            angle = atan2((double)up, (double)down) * (180.0 / M_PI);
            angles->push_back({angle, i});
        } else {
            angles->push_back({0.0, i});
        }
    }
}

int main() {
    int min, index;
    Point p[n], P, Q, R;
    stack<int> st;

    // Input points
    p[0] = {0, 5};
    p[1] = {-3, 2};
    p[2] = {1, 2};
    p[3] = {2, 9};
    p[4] = {2, 4};
    p[5] = {10, 5};
    p[6] = {7, 6};
    p[7] = {4, 7};

    // Find lowest point
    min = p[0].y;
    index = 0;
    for (int i = 1; i < n; i++) {
        if (min == p[i].y) {
            if (p[index].x > p[i].x) {
                min = p[i].y;
                index = i;
            }
        }
        if (min > p[i].y) {
            index = i;
            min = p[i].y;
        }
    }

    // Calculate angles and sort
    vector<pair<double, int>> angles;
    calculate_angles(&angles, index, p);
    sort(angles.begin(), angles.end());

    // Initialize stack
    st.push(angles[0].second);
    st.push(angles[1].second);
    st.push(angles[2].second);

    for (int i = 3; i < n; i++) {
        while (true) {
            if (st.size() < 2) {
                st.push(angles[i].second);
                break;
            }

            int top = st.top();
            st.pop();
            int nextToTop = st.top();
            st.push(top);

            P = p[nextToTop];
            Q = p[top];
            R = p[angles[i].second]; 

            int direction = Direction(P, Q, R);

            if (direction <= 0) {
                st.pop();
            } else {
                st.push(angles[i].second);
                break;
            }
        }
    }

    cout << "Convex Hull:\n";
    vector<Point> result;
    while (!st.empty()) {
        result.push_back(p[st.top()]);
        st.pop();
    }

    reverse(result.begin(), result.end());
    for (auto pt : result) {
        cout << "(" << pt.x << ", " << pt.y << ")\n";
    }

    return 0;
}

