#include <iostream>
using namespace std;

int power(int a, unsigned int n, int p) {
    int res = 1;
    a = a % p;

    while (n > 0) {
        if (n & 1)
            res = (res * a) % p;

        n = n >> 1;
        a = (a * a) % p;
    }
    return res;
}

int main() {
    int a, n, p;
    cin >> a >> n >> p;

    cout << "Result: " << power(a, n, p) << endl;
    return 0;
}
