#include <iostream>
#include <climits>
#include <cmath>
#include <cfloat>

using namespace std;

struct Point {
    int x;
    int y;
};

int Direction(Point P, Point Q, Point R)
{
    // pq x pq
    Point PQ, PR;
    PR.x = R.x - P.x;
    PR.y = R.y - P.y;
    
    PQ.x = Q.x - P.x;
    PQ.y = Q.y - P.y;
    
    int d = (PQ.x * PR.y) - (PQ.y * PR.x);
    
    return d;
}

bool ON_SEGMENT(Point x1, Point x2, Point x3)
{
    if(x3.x >= min(x1.x, x2.x) && x3.x <= max(x1.x, x2.x) && x3.y >= min(x1.y, x2.y) && x3.y <= max(x1.y, x2.y))
        return true;
    return false;
}

int main() {
    Point p, q, r, s;
    p = {1, 1}; 
    q = {4, 8}; 
    r = {2, 6}; 
    s = {6, 3};
    
    int d1, d2, d3, d4;
    d1 = Direction (r, s, p);
    d2 = Direction (r, s, q);
    d3 = Direction (p, q, r);
    d4 = Direction (p, q, s);
    
    if(((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0)))
    {
        cout << true;
    }
    else if(d1 == 0 && ON_SEGMENT(r, s, p))
    {
        cout << true;
    }
    else if(d2 == 0 && ON_SEGMENT(r, s, q))
    {
        cout << true;
    }
    else if(d3 == 0 && ON_SEGMENT(p, q, r))
    {
        cout << true;
    }
    else if(d4 == 0 && ON_SEGMENT(p, q, s))
    {
        cout << true;
    }
    else 
        cout << false;
    return 0;
}
