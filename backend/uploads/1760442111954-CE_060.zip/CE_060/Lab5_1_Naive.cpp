#include <iostream>
#include <string>
#include <vector>
using namespace std;

int main() {
    string T = "AABAACAADAABAABA";
    string P = "AABA";
    string temp;
    vector<int> index;
    int m = P.size();
    int n = T.size();
    for(int i = 0; i < n - m + 1; i++)
    {
        for(int j = 0; j < m; j++)
        {
            temp = T.substr(i, m);
            if(temp == P)
            {
                index.push_back(i);
                break;
            }
        }
    }
    for(int i = 0; i < index.size(); i++)
    {
        cout << "Pattern found at : " << index[i] << endl;
    }
    return 0;
}
