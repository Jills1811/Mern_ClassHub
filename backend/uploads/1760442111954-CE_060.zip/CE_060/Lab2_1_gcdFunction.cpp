#include <iostream>
using namespace std;

int gcd(int a, int b) {
    if (a < b)
        return gcd(b, a);      
    else if (a % b == 0)
        return b;              
    else
        return gcd(b, a % b);  
}

int main() {
    int x, y;
    cout << "Enter two numbers: ";
    cin >> x >> y;
    cout << "GCD of " << x << " and " << y << " is " << gcd(x, y) << endl;
    return 0;
}
