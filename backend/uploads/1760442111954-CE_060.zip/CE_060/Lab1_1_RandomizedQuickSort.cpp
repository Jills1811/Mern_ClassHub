#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace std;

long long comparison_count = 0;

int partition(vector<int>& A, int p, int r) {
    int x = A[r];
    int i = p - 1;
    for (int j = p; j < r; j++) {
        comparison_count++;
        if (A[j] <= x) {
            i++;
            swap(A[i], A[j]);
        }
    }
    swap(A[i + 1], A[r]);
    return i + 1;
}

int randomized_partition(vector<int>& A, int p, int r) {
    int i = p + rand() % (r - p + 1);
    swap(A[r], A[i]);
    return partition(A, p, r);
}

void randomized_quicksort(vector<int>& A, int p, int r) {
    if (p < r) {
        int q = randomized_partition(A, p, r);
        randomized_quicksort(A, p, q - 1);
        randomized_quicksort(A, q + 1, r);
    }
}

int main() {
    srand(time(0));
    int n = 10;


    vector<int> randomArr(n);
    for (int i = 0; i < n; i++) {
        randomArr[i] = rand() % n;
    }

    comparison_count = 0;
    randomized_quicksort(randomArr, 0, n - 1);

    cout << "Random input comparisons: " << comparison_count << endl;
    
    for(int n : randomArr)
        cout << n << " ";
    return 0;
}
