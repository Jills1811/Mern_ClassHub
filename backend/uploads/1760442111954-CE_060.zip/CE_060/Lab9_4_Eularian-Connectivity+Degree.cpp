#include <bits/stdc++.h>
using namespace std;

void dfsUtil(int graph[4][4], int node, vector<bool>& visited) {
    visited[node] = true;

    for (int i = 0; i < 4; i++) {
        if (graph[node][i] && !visited[i]) {
            dfsUtil(graph, i, visited);
        }
    }
}

bool isConnectedUndirected(int graph[4][4], int n) {
    vector<bool> visited(n, false);
    dfsUtil(graph, 0, visited);

    for (bool v : visited) {
        if (!v) return false;
    }
    return true;
}

bool hasEvenDegreeUndirected(int graph[4][4], int n) {
    for (int node = 0; node < n; node++) {
        int degree = 0;
        for (int i = 0; i < n; i++) {
            degree += graph[node][i];
        }
        if (degree % 2 != 0) {
            cout << "Node " << (node + 1) << " has odd degree: " << degree << "\n";
            return false;
        }
    }
    return true;
}

int main() {
    int n = 4;
    // 1->2->3->4->1
    int graph[4][4] = {
    //1  2  3  4
    { 0, 1, 0, 1 }, // 1 
    { 1, 0, 1, 0 }, // 2 
    { 0, 1, 0, 1 }, // 3 
    { 1, 0, 1, 0 }  // 4 
    };

    if (isConnectedUndirected(graph, n)) {
        cout << "Graph is connected\n";

        if (hasEvenDegreeUndirected(graph, n)) {
            cout << "Every node has even degree\n";
        } else {
            cout << "Graph does NOT have even degree for every node\n";
        }
    } else {
        cout << "Graph is NOT connected\n";
    }

    return 0;
}
