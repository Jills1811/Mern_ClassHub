#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int countComp = 0;

void swap(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}

int Partition(int A[], int p, int r) {
    int x = A[r];  
    int i = p - 1;

    for (int j = p; j < r; j++) {
        countComp++;
        if (A[j] <= x) {
            i++;
            swap(A[i], A[j]);
        }
    }
    swap(A[i + 1], A[r]);
    return (i + 1);
}

int Randomized_Partition(int A[], int p, int r) {
    int i = p + rand() % (r - p + 1); 
    swap(A[i], A[r]); 
    return Partition(A, p, r);
}

int Randomized_Find(int A[], int p, int r, int k) {
    if (p == r)
        return A[p];

    int q = Randomized_Partition(A, p, r);
    int m = q - p + 1; 

    if (k == m)
        return A[q];
    else if (k < m)
        return Randomized_Find(A, p, q - 1, k);
    else
        return Randomized_Find(A, q + 1, r, k - m);
}

int main() {
    srand(time(0));

    int n, k;
    cout << "Enter number of elements: ";
    cin >> n;

    int A[n];
    cout << "Enter elements: ";
    for (int i = 0; i < n; i++)
        cin >> A[i];

    cout << "Enter k : ";
    cin >> k;

    int result = Randomized_Find(A, 0, n - 1, k);

    cout << "\nThe " << k << "-th smallest element is: " << result << endl;
    cout << "Total number of comparisons: " << countComp << endl;

    return 0;
}
