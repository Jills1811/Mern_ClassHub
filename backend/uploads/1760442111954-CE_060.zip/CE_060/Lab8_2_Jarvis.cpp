#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;

struct Point {
    int x, y;
};

int orientation(Point p, Point q, Point r) {
    int val = (q.y - p.y)*(r.x - q.x) - (q.x - p.x)*(r.y - q.y);
    if (val == 0) return 0;
    return (val > 0) ? 1 : 2;
}

Point leftmostPoint(vector<Point>& points) {
    int minIdx = 0;
    for (int i = 1; i < points.size(); i++)
        if (points[i].x < points[minIdx].x || 
           (points[i].x == points[minIdx].x && points[i].y < points[minIdx].y))
            minIdx = i;
    return points[minIdx];
}

vector<Point> jarvisMarch(vector<Point>& points) {
    int n = points.size();
    if (n < 3) return points;
    vector<Point> hull;
    int l = 0;
    for (int i = 1; i < n; i++)
        if (points[i].x < points[l].x) l = i;

    int p = l, q;
    do {
        hull.push_back(points[p]);
        q = (p + 1) % n;
        for (int i = 0; i < n; i++)
            if (orientation(points[p], points[i], points[q]) == 2)
                q = i;
        p = q;
    } while (p != l);

    return hull;
}

int main() {
    vector<Point> points = {{0,5},{-3,2},{1,2},{2,9},{2,4},{10,5},{7,6},{4,7}};
    vector<Point> hull = jarvisMarch(points);
    cout << "Convex Hull:\n";
    for (auto p : hull)
        cout << "(" << p.x << ", " << p.y << ")\n";
    return 0;
}
