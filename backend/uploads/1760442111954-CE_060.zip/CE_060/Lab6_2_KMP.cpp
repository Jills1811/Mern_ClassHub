#include <iostream>
#include <string>
#include <vector>
using namespace std;

void constructPI(string &P, vector<int> &pi) {
    int len = 0;
    pi[0] = 0;
    int i = 1;
    while (i < P.length()) {
        if (P[i] == P[len]) {
            len++;
            pi[i] = len;
            i++;
        } 
        else {
            if (len != 0) {
                len = pi[len - 1];
            }
            else {
                pi[i] = 0;
                i++;
            }
        }
    }
}

vector<int> search(string &P, string &T) {
    int n = T.length();
    int m = P.length();

    vector<int> pi(m);
    vector<int> res;
    constructPI(P, pi);
    int i = 0;
    int j = 0;
    while (i < n) {
        if (T[i] == P[j]) {
            i++;
            j++;
            if (j == m) {
                res.push_back(i - j);
                j = pi[j - 1];
            }
        }
        else {
            if (j != 0)
                j = pi[j - 1];
            else
                i++;
        }
    }
    return res;
}

int main() {
    string T = "aabacaaba";
    string P = "aaba";

    vector<int> res = search(P, T);
    for (int i = 0; i < res.size(); i++)
        cout << res[i] << " ";

    return 0;
}
