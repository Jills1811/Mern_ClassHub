#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

using namespace std;

bool isSuffix(string x, string y)
{
    int i, j;
    i = x.length() - 1;
    j = y.length() - 1;

    for (; i >= 0; i--, j--)
    {
        if (j < 0 || x[i] != y[j])
            break;
    }

    if (i < 0)
        return true;
    return false;
}

int main() {
    string T = "aababvaaba";
    string P = "aaba";
    int m = P.length();
    int n = T.length();
    int k;
    int states = P.length() + 1;
    vector<unordered_map<char, int>> delta(states);
    vector<char> E;
    unordered_set<char> seen;
    for (char c : P) {
        if (seen.find(c) == seen.end()) {
            E.push_back(c);
            seen.insert(c);
        }
    }
    for(int q = 0; q < states; q++)
    {
        for(char ch : E)
        {
            k = min(m + 1, q + 2);
            do
            {
                k--;
            }while(!isSuffix(P.substr(0, k), P.substr(0, q) + string(1, ch)));
            delta[q][ch] = k;
        }
    }
    // int q = 0;
    int q = 0;
    for (int i = 0; i < n; i++) {
        char c = T[i];
        if (delta[q].find(c) != delta[q].end()) {
            q = delta[q][c];
        } else {
            q = 0;  // no transition for this char, go to state 0
        }
        if (q == m) {
            cout << (i - m + 1) << " ";  // 1-based indexing for output
        }
    }
    return 0;
}
