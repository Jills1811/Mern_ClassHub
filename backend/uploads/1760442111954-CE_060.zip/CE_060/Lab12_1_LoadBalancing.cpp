#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
#include <queue>
using namespace std;

struct Machine {
    int id;
    long long currentLoad;
    bool operator>(const Machine& other) const {
        return currentLoad > other.currentLoad;
    }
};

vector<vector<int>> greedyLoadBalancing(const vector<int>& jobProcessingTimes, int numMachines) {
    int numJobs = jobProcessingTimes.size();
    if (numJobs == 0 || numMachines <= 0) {
        return {};
    }

    priority_queue<Machine, vector<Machine>, greater<Machine>> machines;
    for (int i = 0; i < numMachines; ++i) {
        machines.push({i, 0});
    }

    vector<vector<int>> assignedJobs(numMachines);

    for (int i = 0; i < numJobs; ++i) {
        Machine leastLoadedMachine = machines.top();
        machines.pop();
        assignedJobs[leastLoadedMachine.id].push_back(jobProcessingTimes[i]);
        leastLoadedMachine.currentLoad += jobProcessingTimes[i];
        machines.push(leastLoadedMachine);
    }

    return assignedJobs;
}

int main() {
    vector<int> jobProcessingTimes = {1, 2, 8, 44, 7, 3, 9};
    int numMachines = 3;
    // sort(jobProcessingTimes.begin(), jobProcessingTimes.end());
    vector<vector<int>> assignment = greedyLoadBalancing(jobProcessingTimes, numMachines);

    long long maxMakespan = 0;
    for (int i = 0; i < numMachines; ++i) {
        long long currentMachineLoad = 0;
        cout << "Machine " << i << " jobs: ";
        for (int jobTime : assignment[i]) {
            cout << jobTime << " ";
            currentMachineLoad += jobTime;
        }
        cout << "(Total Load: " << currentMachineLoad << ")" << endl;
        if (currentMachineLoad > maxMakespan) {
            maxMakespan = currentMachineLoad;
        }
    }

    cout << "Maximum Makespan (Approximation): " << maxMakespan << endl;
    return 0;
}
