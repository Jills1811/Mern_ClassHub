#include <iostream>
#include <climits>
#include <cmath>
#include <cfloat>

using namespace std;

struct Point {
    int x;
    int y;
};

int main() {
    int n = 5;
    Point p[n];
    p[0] = {2, 5};
    p[1] = {5, 7};
    p[2] = {-3, -5};
    p[3] = {-1, 2};
    p[4] = {0, 7};

    double P[n][n];

    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            if(i == j) 
                P[i][j] = 0.0;
            else
                P[i][j] = sqrt(pow(p[i].x - p[j].x, 2) + pow(p[i].y - p[j].y, 2));
        }
    }

    double dmin = DBL_MAX;
    int index1 = -1, index2 = -1;

    for(int i = 0; i < n - 1; i++) {
        for(int j = i + 1; j < n; j++) {
            if(P[i][j] < dmin) {
                dmin = P[i][j];
                index1 = i;
                index2 = j;
            }
        }
    }

    cout << "The closest points are: (" << p[index1].x << ", " << p[index1].y << ") and ("
         << p[index2].x << ", " << p[index2].y << ")" << endl;
    cout << "Their distance is: " << dmin << endl;

    return 0;
}
