#include <bits/stdc++.h>
using namespace std;
int n = 9;
int parent[6];
int visited[6];

bool bfs(int rg[9][9], int source, int sink)
{
    queue<int> q;
    q.push(source);
    fill(visited, visited + n, 0);
    // Enqueue(q, source);
    visited[source] = 1;
    parent[source] = -1;
    while(!q.empty())
    {
        // int u = dequeue(q);
        int u = q.front();
        q.pop();
        for(int v = 0; v < n; v++)
        {
            if(visited[v] == 0 && rg[u][v] > 0)
            {
                if(v == sink)
                {
                    parent[v] = u;
                    return true;
                }
            q.push(v);
            visited[v] = 1;
            parent[v] = u;
            }
        }
    }
    return false;
}
int fordfulkerson(int graph[9][9], int source, int sink)
{
    int rg[9][9];
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            rg[i][j] = graph[i][j];
        }
        parent[i] = i;
    }
    int maxflow = 0; 
    while(bfs(rg, source, sink))
    {
        int path_flow = INT_MAX;
        for(int v = sink; v != source; v = parent[v])
        {
            int u = parent[v];
            path_flow = min(path_flow, rg[u][v]);
        }
        for(int v = sink; v != source; v = parent[v])
        {
            int u = parent[v];
            rg[u][v] -= path_flow;
            rg[v][u] += path_flow;
        }
        // cout << "Residual graph : " << endl;
        // for(int i = 0; i < n; i++)
        // {
        //     for(int j = 0; j < n; j++)
        //     {
        //         cout << rg[i][j] << " ";
        //     }
        //     cout << endl;
        // }
        // cout << "Path flow : " << path_flow << endl;
        maxflow += path_flow;
        // cout << maxflow;
    }
    return maxflow;
}

int main() {
    int n = 9;
    int source = 0;  // S
    int sink = 8;    // T
    int graph[9][9] = {
    // S  1  2  3  a  b  c  d  T
    { 0, 1, 1, 1, 0, 0, 0, 0, 0 }, // S (0)
    { 0, 0, 0, 0, 0, 1, 0, 0, 0 }, // 1 (1)
    { 0, 0, 0, 0, 1, 1, 1, 0, 0 }, // 2 (2)
    { 0, 0, 0, 0, 0, 1, 0, 1, 0 }, // 3 (3)
    { 0, 0, 0, 0, 0, 0, 0, 0, 1 }, // a (4)
    { 0, 0, 0, 0, 0, 0, 0, 0, 1 }, // b (5)
    { 0, 0, 0, 0, 0, 0, 0, 0, 1 }, // c (6)
    { 0, 0, 0, 0, 0, 0, 0, 0, 1 }, // d (7)
    { 0, 0, 0, 0, 0, 0, 0, 0, 0 }  // T (8)
    };  
    cout << fordfulkerson(graph, 0, 5);
    return 0;
}
