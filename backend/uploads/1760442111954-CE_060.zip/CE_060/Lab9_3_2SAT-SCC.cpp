#include <bits/stdc++.h>
using namespace std;

struct TwoSAT {
    int n;
    vector<vector<int>> g, gr;
    vector<int> order, comp;
    vector<bool> used, assignment;

    TwoSAT(int vars) {
        n = vars;
        g.resize(2 * n);
        gr.resize(2 * n);
        used.resize(2 * n, false);
        comp.resize(2 * n, -1);
        assignment.resize(n, false);
    }

    int neg(int x) { return x >= n ? x - n : x + n; }

    void add_clause(int a, int b) {
        g[neg(a)].push_back(b);
        g[neg(b)].push_back(a);
        gr[b].push_back(neg(a));
        gr[a].push_back(neg(b));
    }

    void dfs1(int v) {
        used[v] = true;
        for (int u : g[v]) if (!used[u]) dfs1(u);
        order.push_back(v);
    }

    void dfs2(int v, int cl) {
        comp[v] = cl;
        for (int u : gr[v]) if (comp[u] == -1) dfs2(u, cl);
    }

    bool satisfiable() {
        for (int i = 0; i < 2*n; i++) used[i] = false;
        order.clear();
        for (int i = 0; i < 2*n; i++) if (!used[i]) dfs1(i);
        for (int i = 0; i < 2*n; i++) comp[i] = -1;
        int j = 0;
        for (int i = 2*n-1; i >= 0; i--) if (comp[order[i]] == -1) dfs2(order[i], j++);
        for (int i = 0; i < n; i++) if (comp[i] == comp[neg(i)]) return false;
        vector<pair<int,int>> tmp;
        for (int i = 0; i < n; i++) tmp.push_back({comp[i], i});
        sort(tmp.rbegin(), tmp.rend());
        vector<bool> val(2*n, false);
        for (auto p : tmp) {
            int i = p.second;
            if (!val[i] && !val[neg(i)]) assignment[i] = true, val[i] = true, val[neg(i)] = false;
        }
        return true;
    }
};

int main() {
    int vars = 3;
    TwoSAT solver(vars);
    solver.add_clause(0, 1);
    solver.add_clause(1, 2);
    solver.add_clause(2, 0);
    if (solver.satisfiable()) {
        cout << "Satisfiable\n";
        for (int i = 0; i < vars; i++)
            cout << "x" << i << " = " << solver.assignment[i] << "\n";
    } else cout << "Unsatisfiable\n";
}
