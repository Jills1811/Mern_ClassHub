#include <iostream>
#include <string>
#include <vector>
using namespace std;

int CheckInT(string& P, char c)
{
    for(int i = P.size() - 2; i >= 0; i--) 
    {
        if(c == P[i])
            return i;
    }
    return -1;
}

int main() {
    string T = "JIM_SAW_ME_IN_A_BARBER_SHOP";
    string P = "BARBER";
    vector<int> index;
    int m = P.size();
    int n = T.size();
    int temp_index = 0;

    while(temp_index + m <= n)
    {
        int j = m - 1;
        while(j >= 0 && P[j] == T[temp_index + j])
            j--;

        if(j < 0)
        {
            index.push_back(temp_index);
            temp_index += m;
        }
        else
        {
            int shift = CheckInT(P, T[temp_index + m - 1]);
            if(shift != -1)
                temp_index += m - 1 - shift;
            else
                temp_index += m;
        }
    }

    for(int i = 0; i < index.size(); i++)
    {
        cout << "Pattern found at: " << index[i] << endl;
    }
    return 0;
}
