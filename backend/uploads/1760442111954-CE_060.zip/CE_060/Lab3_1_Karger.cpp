#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <climits>
using namespace std;

int n = 4;

int find(vector<int>& Parent, int i) {
    if (Parent[i] != i)
        Parent[i] = find(Parent, Parent[i]);
    return Parent[i];
}

void unionByRank(vector<int>& Parent, vector<int>& Rank, int i, int j) {
    int irep = find(Parent, i);
    int jrep = find(Parent, j);
    if (irep == jrep) return;
    if (Rank[irep] < Rank[jrep])
        Parent[irep] = jrep;
    else if (Rank[irep] > Rank[jrep])
        Parent[jrep] = irep;
    else {
        Parent[jrep] = irep;
        Rank[irep]++;
    }
}

int karger(int graph[4][4]) {
    vector<vector<int>> edges;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (graph[i][j] == 1)
                edges.push_back({i, j});
        }
    }

    vector<int> Parent(n);
    vector<int> Rank(n, 0);
    for (int i = 0; i < n; i++) Parent[i] = i;

    int remainingSets = n;

    while (remainingSets > 2) {
        int x = rand() % edges.size();
        int u = edges[x][0];
        int v = edges[x][1];

        int setU = find(Parent, u);
        int setV = find(Parent, v);

        if (setU != setV) {
            unionByRank(Parent, Rank, setU, setV);
            remainingSets--;
        }
    }

    int cutEdges = 0;
    for (auto& edge : edges) {
        if (find(Parent, edge[0]) != find(Parent, edge[1]))
            cutEdges++;
    }

    return cutEdges;
}

int main() {
    srand(time(0));
    int graph[4][4] = { {0, 1, 1, 1},
                        {1, 0, 1, 0},
                        {1, 1, 0, 1},
                        {1, 0, 1, 0} };

    int trials = 100;
    int minCut = INT_MAX;

    for (int i = 0; i < trials; i++) {
        int cut = karger(graph);
        if (cut < minCut)
            minCut = cut;
    }

    cout << "Minimum cut found: " << minCut << endl;
    return 0;
}
