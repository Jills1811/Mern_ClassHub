#include <bits/stdc++.h>
using namespace std;

int main() {
    int n = 1000, trials = 1000;
    double total_hires = 0;

    for(int t = 0; t < trials; t++) {
        vector<int> a(n);
        for(int i = 0; i < n; i++) a[i] = i+1;
        shuffle(a.begin(), a.end(), default_random_engine(rand()));

        int best = 0, hires = 0;
        for(int i = 0; i < n; i++) {
            if(a[i] > best) {
                best = a[i];
                hires++;
            }
        }
        total_hires += hires;
    }

    cout << "Average hires over " << trials << " trials: " << total_hires / trials << endl;
    return 0;
}
