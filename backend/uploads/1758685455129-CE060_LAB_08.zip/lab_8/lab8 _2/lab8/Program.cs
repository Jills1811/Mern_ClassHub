﻿using System;
using Calc;
namespace lab8
{
    internal class Application
    {
        static void Main(string[] args)
        {
            int a = 15;
            int b = 5;
           int r = Program.Add(a, b);
            Console.WriteLine("sum: "+r);
             r= Program.Sub(a, b);
            Console.WriteLine("sub: " + r);
             r = Program.Mul(a, b);
            Console.WriteLine("Mul: " + r);
            r= Program.Div(a, b);

            Console.WriteLine("sum: " + r);


            Console.ReadLine();
        }
    }
}
