﻿using System;

namespace Calc
{
    public class Program
    {
        public static int Add(int x, int y)
        {
            return x + y;
        }
    }
}
