﻿using System;
using Calc;
namespace lab8
{
    internal class Application
    {
        static void Main(string[] args)
        {
            int a = 5;
            int b = 10;
           int r = Program.Add(a, b);
            Console.WriteLine(r);
            Console.ReadLine();
        }
    }
}
