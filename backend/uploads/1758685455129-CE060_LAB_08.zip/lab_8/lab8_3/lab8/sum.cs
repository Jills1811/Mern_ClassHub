﻿using System;

namespace add
{
    public class Program2
    {
       public  static int addition(int a, int b)
        {
            return a + b;
        }
    }
}
