﻿using System;
using add;
using sb;

namespace lab8
{
    internal class Application
    {
        static void Main(string[] args)
        {
           int a=10; int b=10;
            int r=Program2.addition(a,b);
            Console.WriteLine("sum: "+r);
            r=Program1.subtract(a,b);
            Console.WriteLine("sub: " + r);
        }
    }
}
