﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sb
{
    public class Program1
    {
      public   static int subtract(int a, int b) {  return a - b; }
    }
}
